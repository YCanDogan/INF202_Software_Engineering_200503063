/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Database;

/**
 *
 * @author canba
 */
public class Configs {

    // In video const. type is private --> IMPORTANT
    public static final String username = "root";
    public static final String password = "password";
    public static final String dataConn = "jdbc:mysql://localhost:3306/cleanapp";

}
